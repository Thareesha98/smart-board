package com.sbms.sbms_notification_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbmsNotificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
