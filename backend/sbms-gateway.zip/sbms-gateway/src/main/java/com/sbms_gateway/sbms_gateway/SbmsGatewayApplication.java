package com.sbms_gateway.sbms_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbmsGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbmsGatewayApplication.class, args);
	}

}
