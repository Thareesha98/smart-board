package com.sbms.sbms_monolith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbmsMonolithApplicationTests {

	@Test
	void contextLoads() {
	}

}
